﻿(async () => {
    const contentElement = document.getElementById('content');

    const setupLogin = (response) => {
        const loginButtonElement = document.getElementById('loginButton');

        if (response.needLogin) {
            contentElement.classList.add('yp-popup-content--need-login');
        }

        loginButtonElement.onclick = () => {
            chrome.runtime.sendMessage({ name: 'Login' }, (response) => {
                if (response.ok) {
                    contentElement.classList.remove('yp-popup-content--need-login');
                }
            });
        };
    };

    const setupQuotaExceeded = (response) => {
        if (response.quotaExceeded) {
            const element = document.querySelector('.yp-popup-quota-exceeded');
            element.classList.add('yp-popup-quota-exceeded--active');
        }
    };

    chrome.runtime.sendMessage({ name: 'PopupInfo' },
        (response) => {
            const addedElement = document.getElementById('added');
            const removedElement = document.getElementById('removed');
            const totalElement = document.getElementById('total');
            contentElement.classList.add('yp-popup-content--loaded');

            addedElement.textContent = response.added;
            removedElement.textContent = response.removed;
            totalElement.textContent = response.total;

            const urlElement = document.getElementById('url');
            urlElement.href = response.url;
            setupLogin(response);
            setupQuotaExceeded(response);
        });
})();